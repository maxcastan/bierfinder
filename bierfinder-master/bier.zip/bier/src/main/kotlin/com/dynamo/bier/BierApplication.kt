package com.dynamo.bier

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class BierApplication

fun main(args: Array<String>) {
	runApplication<BierApplication>(*args)
}
