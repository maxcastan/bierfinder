package com.dynamo.bier

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class BierApplicationTests {

	@Test
	fun contextLoads() {
	}

}
